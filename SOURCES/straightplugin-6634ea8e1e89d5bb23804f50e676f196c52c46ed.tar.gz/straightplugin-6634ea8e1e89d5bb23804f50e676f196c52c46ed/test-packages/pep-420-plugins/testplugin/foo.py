def do(x):
    return x + " from pep-420"
