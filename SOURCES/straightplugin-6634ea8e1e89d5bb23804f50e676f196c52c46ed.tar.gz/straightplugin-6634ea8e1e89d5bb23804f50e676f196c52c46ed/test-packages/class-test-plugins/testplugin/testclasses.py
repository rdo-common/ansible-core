class A(object):
    class __plugin__:
        priority = 0.5


class B(object):
    class __plugin__:
        priority = 1.0


class A1(A):
    pass
