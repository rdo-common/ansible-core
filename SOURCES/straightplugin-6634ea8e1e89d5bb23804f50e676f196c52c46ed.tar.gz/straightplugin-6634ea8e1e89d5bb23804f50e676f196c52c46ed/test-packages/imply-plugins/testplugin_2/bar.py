def do(x):
    return x + 1
