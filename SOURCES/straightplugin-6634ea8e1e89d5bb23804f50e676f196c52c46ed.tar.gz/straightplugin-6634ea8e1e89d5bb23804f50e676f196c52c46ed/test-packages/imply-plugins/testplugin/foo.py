class __plugin__:
    imply_plugins = ("testplugin_2",)
    load = False


def do(x):
    return x + 1
