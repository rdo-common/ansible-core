def do(i):
    return i + 3
