def do(i):
    return "quu"
