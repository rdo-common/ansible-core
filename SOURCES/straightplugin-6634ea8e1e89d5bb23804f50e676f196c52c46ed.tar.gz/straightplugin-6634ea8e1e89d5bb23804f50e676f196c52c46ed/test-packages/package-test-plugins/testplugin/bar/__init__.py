def do(i):
    return i + 1
