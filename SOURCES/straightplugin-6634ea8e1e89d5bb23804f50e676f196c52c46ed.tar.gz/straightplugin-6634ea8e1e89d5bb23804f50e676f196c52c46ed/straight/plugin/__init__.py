from straight.plugin import loaders

load = loaders.unified_load
